# ============================================================
# BE Technology — GL Intelligence Platform
# Unified FASB Compliance Terraform
#
# Mandates covered:
#   Module 1 — DISE          · ASU 2024-03 / ASC 220-40
#   Module 2 — Tax Recon     · ASU 2023-09 / ASC 740
#   Module 3 — Segment Rptg  · ASU 2023-07 / ASC 280
#
# GCP stack: BigQuery · Cloud Run · Cloud Scheduler
#            Vertex AI · Secret Manager · IAM
#
# Deploy sequence:
#   terraform workspace new {client_id}
#   terraform apply -var-file=clients/{client_id}.tfvars
#
# Import existing diplomatic75 resources first:
#   terraform import google_bigquery_dataset.dise_reporting \
#     projects/diplomatic75/datasets/dise_reporting
# ============================================================

terraform {
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
  }
  required_version = ">= 1.5"
}

provider "google" {
  project = var.project_id
  region  = var.region
}

# ── Local values ──────────────────────────────────────────────
locals {
  sa_email = google_service_account.fasb_agent.email
  labels = {
    managed_by  = "terraform"
    product     = "gl-intelligence-platform"
    client      = var.client_id
    environment = var.environment
  }
}

data "google_project" "project" {
  project_id = var.project_id
}


# ============================================================
# SECTION 1 — BIGQUERY DATASET
# ============================================================

resource "google_bigquery_dataset" "dise_reporting" {
  dataset_id                 = var.dataset_id
  friendly_name              = "GL Intelligence Platform — ${var.client_name}"
  description                = "FASB compliance layer: DISE (ASU 2024-03), Tax Reconciliation (ASU 2023-09), Segment Reporting (ASU 2023-07)"
  location                   = var.bq_location
  delete_contents_on_destroy = false
  labels                     = local.labels

  access {
    role          = "OWNER"
    user_by_email = var.admin_email
  }
  access {
    role          = "WRITER"
    user_by_email = local.sa_email
  }
  access {
    role          = "READER"
    user_by_email = var.controller_email
  }
}


# ============================================================
# SECTION 2 — MODULE 1: DISE TABLES (ASU 2024-03)
# 7 tables — GL mapping, expense disaggregation, audit trail,
# anomaly alerts, pending mappings, close tracker
# ============================================================

resource "google_bigquery_table" "gl_dise_mapping" {
  dataset_id          = google_bigquery_dataset.dise_reporting.dataset_id
  table_id            = "gl_dise_mapping"
  deletion_protection = true
  description         = "GL account to DISE natural expense category mapping. Core classification layer for ASU 2024-03 disclosure."
  labels              = merge(local.labels, { module = "dise", standard = "asu_2024_03" })

  schema = jsonencode([
    { name = "gl_account",      type = "STRING",    mode = "REQUIRED", description = "SAP GL account (HKONT)" },
    { name = "description",     type = "STRING",    mode = "NULLABLE", description = "Account description from SKA1" },
    { name = "dise_category",   type = "STRING",    mode = "NULLABLE", description = "ASU 2024-03 natural expense category" },
    { name = "expense_caption", type = "STRING",    mode = "NULLABLE", description = "Income statement caption: COGS | SG&A | R&D | Other" },
    { name = "segment_id",      type = "STRING",    mode = "NULLABLE", description = "ASU 2023-07 segment ID — links DISE to segment module" },
    { name = "status",          type = "STRING",    mode = "NULLABLE", description = "mapped | unmapped | review | excluded" },
    { name = "notes",           type = "STRING",    mode = "NULLABLE", description = "Methodology notes and rationale" },
    { name = "reviewer",        type = "STRING",    mode = "NULLABLE", description = "Approving reviewer email" },
    { name = "asc_citation",    type = "STRING",    mode = "NULLABLE", description = "ASC 220-40 citation" },
    { name = "ai_confidence",   type = "FLOAT64",   mode = "NULLABLE", description = "Gemini classifier confidence 0.0-1.0" },
    { name = "ai_reasoning",    type = "STRING",    mode = "NULLABLE", description = "AI classification rationale" },
    { name = "created_at",      type = "TIMESTAMP", mode = "NULLABLE" },
    { name = "updated_at",      type = "TIMESTAMP", mode = "NULLABLE" }
  ])
}

resource "google_bigquery_table" "fact_expense_disagg" {
  dataset_id          = google_bigquery_dataset.dise_reporting.dataset_id
  table_id            = "fact_expense_disagg"
  deletion_protection = false
  description         = "Disaggregated expense output by DISE category. Produced by the DISE pivot query at period close."
  labels              = merge(local.labels, { module = "dise", standard = "asu_2024_03" })

  time_partitioning {
    type  = "MONTH"
    field = "posting_date"
  }
  clustering = ["company_code", "fiscal_year", "dise_category"]

  schema = jsonencode([
    { name = "company_code",    type = "STRING",    mode = "REQUIRED" },
    { name = "fiscal_year",     type = "STRING",    mode = "REQUIRED" },
    { name = "fiscal_period",   type = "STRING",    mode = "REQUIRED" },
    { name = "posting_date",    type = "DATE",      mode = "NULLABLE" },
    { name = "gl_account",      type = "STRING",    mode = "NULLABLE" },
    { name = "dise_category",   type = "STRING",    mode = "NULLABLE" },
    { name = "expense_caption", type = "STRING",    mode = "NULLABLE" },
    { name = "segment_id",      type = "STRING",    mode = "NULLABLE" },
    { name = "amount_local",    type = "NUMERIC",   mode = "NULLABLE" },
    { name = "currency",        type = "STRING",    mode = "NULLABLE" },
    { name = "posting_count",   type = "INT64",     mode = "NULLABLE" },
    { name = "run_id",          type = "STRING",    mode = "NULLABLE" },
    { name = "loaded_at",       type = "TIMESTAMP", mode = "NULLABLE" }
  ])
}

resource "google_bigquery_table" "pending_mappings" {
  dataset_id          = google_bigquery_dataset.dise_reporting.dataset_id
  table_id            = "pending_mappings"
  deletion_protection = false
  description         = "DISE AI draft mappings awaiting human approval before promotion to gl_dise_mapping."
  labels              = merge(local.labels, { module = "dise" })

  schema = jsonencode([
    { name = "pending_id",       type = "STRING",    mode = "NULLABLE" },
    { name = "gl_account",       type = "STRING",    mode = "NULLABLE" },
    { name = "description",      type = "STRING",    mode = "NULLABLE" },
    { name = "ai_category",      type = "STRING",    mode = "NULLABLE" },
    { name = "ai_caption",       type = "STRING",    mode = "NULLABLE" },
    { name = "ai_confidence",    type = "FLOAT64",   mode = "NULLABLE" },
    { name = "ai_reasoning",     type = "STRING",    mode = "NULLABLE" },
    { name = "ai_asc_citation",  type = "STRING",    mode = "NULLABLE" },
    { name = "model_version",    type = "STRING",    mode = "NULLABLE" },
    { name = "prompt_version",   type = "STRING",    mode = "NULLABLE" },
    { name = "status",           type = "STRING",    mode = "NULLABLE", description = "pending | approved | rejected | promoted" },
    { name = "reviewed_by",      type = "STRING",    mode = "NULLABLE" },
    { name = "reviewed_at",      type = "STRING",    mode = "NULLABLE" },
    { name = "override_category",type = "STRING",    mode = "NULLABLE" },
    { name = "override_reason",  type = "STRING",    mode = "NULLABLE" },
    { name = "created_at",       type = "STRING",    mode = "NULLABLE" },
    { name = "updated_at",       type = "STRING",    mode = "NULLABLE" }
  ])
}

resource "google_bigquery_table" "mapping_decisions_log" {
  dataset_id          = google_bigquery_dataset.dise_reporting.dataset_id
  table_id            = "mapping_decisions_log"
  deletion_protection = true
  description         = "Immutable audit trail of all GL mapping decisions. Four-link chain: AI draft → human review → approval → promotion."
  labels              = merge(local.labels, { module = "dise" })

  schema = jsonencode([
    { name = "log_id",          type = "STRING",    mode = "REQUIRED" },
    { name = "gl_account",      type = "STRING",    mode = "NULLABLE" },
    { name = "action",          type = "STRING",    mode = "NULLABLE", description = "drafted | reviewed | approved | promoted | rejected" },
    { name = "actor",           type = "STRING",    mode = "NULLABLE" },
    { name = "from_status",     type = "STRING",    mode = "NULLABLE" },
    { name = "to_status",       type = "STRING",    mode = "NULLABLE" },
    { name = "dise_category",   type = "STRING",    mode = "NULLABLE" },
    { name = "ai_confidence",   type = "FLOAT64",   mode = "NULLABLE" },
    { name = "notes",           type = "STRING",    mode = "NULLABLE" },
    { name = "logged_at",       type = "TIMESTAMP", mode = "REQUIRED" }
  ])
}

resource "google_bigquery_table" "anomaly_alerts" {
  dataset_id          = google_bigquery_dataset.dise_reporting.dataset_id
  table_id            = "anomaly_alerts"
  deletion_protection = false
  description         = "Vertex AI anomaly detection alerts for GL postings outside expected DISE patterns."
  labels              = merge(local.labels, { module = "dise" })

  time_partitioning {
    type  = "DAY"
    field = "detected_at"
  }

  schema = jsonencode([
    { name = "alert_id",        type = "STRING",    mode = "REQUIRED" },
    { name = "gl_account",      type = "STRING",    mode = "NULLABLE" },
    { name = "company_code",    type = "STRING",    mode = "NULLABLE" },
    { name = "fiscal_period",   type = "STRING",    mode = "NULLABLE" },
    { name = "alert_type",      type = "STRING",    mode = "NULLABLE" },
    { name = "severity",        type = "STRING",    mode = "NULLABLE", description = "high | medium | low" },
    { name = "amount",          type = "NUMERIC",   mode = "NULLABLE" },
    { name = "expected_amount", type = "NUMERIC",   mode = "NULLABLE" },
    { name = "variance_pct",    type = "FLOAT64",   mode = "NULLABLE" },
    { name = "description",     type = "STRING",    mode = "NULLABLE" },
    { name = "status",          type = "STRING",    mode = "NULLABLE", description = "open | reviewed | resolved" },
    { name = "detected_at",     type = "TIMESTAMP", mode = "NULLABLE" },
    { name = "resolved_at",     type = "TIMESTAMP", mode = "NULLABLE" }
  ])
}

resource "google_bigquery_table" "close_tasks" {
  dataset_id          = google_bigquery_dataset.dise_reporting.dataset_id
  table_id            = "close_tasks"
  deletion_protection = false
  description         = "Period close task tracker. Six standard tasks per close cycle."
  labels              = merge(local.labels, { module = "dise" })

  schema = jsonencode([
    { name = "task_id",         type = "STRING",    mode = "REQUIRED" },
    { name = "task_name",       type = "STRING",    mode = "NULLABLE" },
    { name = "description",     type = "STRING",    mode = "NULLABLE" },
    { name = "status",          type = "STRING",    mode = "NULLABLE", description = "pending | in_progress | complete | error" },
    { name = "assigned_to",     type = "STRING",    mode = "NULLABLE" },
    { name = "due_date",        type = "DATE",      mode = "NULLABLE" },
    { name = "completed_at",    type = "TIMESTAMP", mode = "NULLABLE" },
    { name = "fiscal_period",   type = "STRING",    mode = "NULLABLE" },
    { name = "notes",           type = "STRING",    mode = "NULLABLE" },
    { name = "updated_at",      type = "TIMESTAMP", mode = "NULLABLE" }
  ])
}

resource "google_bigquery_table" "close_task_history" {
  dataset_id          = google_bigquery_dataset.dise_reporting.dataset_id
  table_id            = "close_task_history"
  deletion_protection = false
  description         = "Historical record of close task completions by period."
  labels              = merge(local.labels, { module = "dise" })

  schema = jsonencode([
    { name = "history_id",      type = "STRING",    mode = "REQUIRED" },
    { name = "task_id",         type = "STRING",    mode = "NULLABLE" },
    { name = "fiscal_period",   type = "STRING",    mode = "NULLABLE" },
    { name = "status",          type = "STRING",    mode = "NULLABLE" },
    { name = "completed_by",    type = "STRING",    mode = "NULLABLE" },
    { name = "completed_at",    type = "TIMESTAMP", mode = "NULLABLE" },
    { name = "duration_minutes",type = "INT64",     mode = "NULLABLE" },
    { name = "notes",           type = "STRING",    mode = "NULLABLE" }
  ])
}


# ============================================================
# SECTION 3 — MODULE 2: TAX RECONCILIATION TABLES (ASU 2023-09)
# 7 tables — GL mapping, pending, provision universe,
# ETR lines, taxes paid, statutory rates, disclosure output
# ============================================================

resource "google_bigquery_table" "tax_gl_mapping" {
  dataset_id          = google_bigquery_dataset.dise_reporting.dataset_id
  table_id            = "tax_gl_mapping"
  deletion_protection = true
  description         = "GL account to ASU 2023-09 tax category mapping. Core classification layer for the ETR bridge."
  labels              = merge(local.labels, { module = "tax_reconciliation", standard = "asu_2023_09" })

  schema = jsonencode([
    { name = "gl_account",         type = "STRING",    mode = "REQUIRED" },
    { name = "description",        type = "STRING",    mode = "NULLABLE" },
    { name = "tax_category",       type = "STRING",    mode = "NULLABLE", description = "current_tax | deferred_tax | uncertain_tax | valuation_allowance | pretax_income | other | not_applicable" },
    { name = "jurisdiction_type",  type = "STRING",    mode = "NULLABLE", description = "federal | state | foreign | not_applicable" },
    { name = "country_code",       type = "STRING",    mode = "NULLABLE" },
    { name = "etr_line_category",  type = "STRING",    mode = "NULLABLE", description = "ASU 2023-09 prescribed ETR reconciliation category" },
    { name = "pretax_income_type", type = "STRING",    mode = "NULLABLE", description = "domestic | foreign | not_applicable" },
    { name = "taxes_paid_type",    type = "STRING",    mode = "NULLABLE", description = "cash_taxes_paid | not_applicable" },
    { name = "status",             type = "STRING",    mode = "NULLABLE", description = "mapped | unmapped | review | excluded" },
    { name = "ai_confidence",      type = "FLOAT64",   mode = "NULLABLE" },
    { name = "ai_reasoning",       type = "STRING",    mode = "NULLABLE" },
    { name = "reviewer",           type = "STRING",    mode = "NULLABLE" },
    { name = "reviewed_at",        type = "TIMESTAMP", mode = "NULLABLE" },
    { name = "asc_citation",       type = "STRING",    mode = "NULLABLE" },
    { name = "notes",              type = "STRING",    mode = "NULLABLE" },
    { name = "created_at",         type = "TIMESTAMP", mode = "NULLABLE" },
    { name = "updated_at",         type = "TIMESTAMP", mode = "NULLABLE" }
  ])
}

resource "google_bigquery_table" "tax_pending_mappings" {
  dataset_id          = google_bigquery_dataset.dise_reporting.dataset_id
  table_id            = "tax_pending_mappings"
  deletion_protection = false
  description         = "Tax module AI draft mappings awaiting human approval."
  labels              = merge(local.labels, { module = "tax_reconciliation" })

  schema = jsonencode([
    { name = "pending_id",        type = "STRING",  mode = "NULLABLE" },
    { name = "gl_account",        type = "STRING",  mode = "NULLABLE" },
    { name = "description",       type = "STRING",  mode = "NULLABLE" },
    { name = "ai_tax_category",   type = "STRING",  mode = "NULLABLE" },
    { name = "ai_jurisdiction",   type = "STRING",  mode = "NULLABLE" },
    { name = "ai_etr_line",       type = "STRING",  mode = "NULLABLE" },
    { name = "ai_pretax_type",    type = "STRING",  mode = "NULLABLE" },
    { name = "ai_taxes_paid",     type = "STRING",  mode = "NULLABLE" },
    { name = "ai_confidence",     type = "FLOAT64", mode = "NULLABLE" },
    { name = "ai_reasoning",      type = "STRING",  mode = "NULLABLE" },
    { name = "ai_asc_citation",   type = "STRING",  mode = "NULLABLE" },
    { name = "model_version",     type = "STRING",  mode = "NULLABLE" },
    { name = "prompt_version",    type = "STRING",  mode = "NULLABLE" },
    { name = "status",            type = "STRING",  mode = "NULLABLE" },
    { name = "reviewed_by",       type = "STRING",  mode = "NULLABLE" },
    { name = "reviewed_at",       type = "STRING",  mode = "NULLABLE" },
    { name = "override_category", type = "STRING",  mode = "NULLABLE" },
    { name = "override_reason",   type = "STRING",  mode = "NULLABLE" },
    { name = "created_at",        type = "STRING",  mode = "NULLABLE" },
    { name = "updated_at",        type = "STRING",  mode = "NULLABLE" }
  ])
}

resource "google_bigquery_table" "tax_provision_universe" {
  dataset_id          = google_bigquery_dataset.dise_reporting.dataset_id
  table_id            = "tax_provision_universe"
  deletion_protection = false
  description         = "Tax provision universe — one row per legal entity per period. Foundation for ASU 2023-09 disclosure tables."
  labels              = merge(local.labels, { module = "tax_reconciliation", standard = "asu_2023_09" })

  time_partitioning {
    type  = "MONTH"
    field = "posting_date"
  }
  clustering = ["company_code", "fiscal_year"]

  schema = jsonencode([
    { name = "company_code",           type = "STRING",    mode = "REQUIRED" },
    { name = "fiscal_year",            type = "STRING",    mode = "REQUIRED" },
    { name = "fiscal_period",          type = "STRING",    mode = "REQUIRED" },
    { name = "posting_date",           type = "DATE",      mode = "NULLABLE" },
    { name = "currency",               type = "STRING",    mode = "NULLABLE" },
    { name = "jurisdiction_type",      type = "STRING",    mode = "NULLABLE" },
    { name = "current_tax_federal",    type = "NUMERIC",   mode = "NULLABLE" },
    { name = "current_tax_state",      type = "NUMERIC",   mode = "NULLABLE" },
    { name = "current_tax_foreign",    type = "NUMERIC",   mode = "NULLABLE" },
    { name = "current_tax_total",      type = "NUMERIC",   mode = "NULLABLE" },
    { name = "deferred_tax_federal",   type = "NUMERIC",   mode = "NULLABLE" },
    { name = "deferred_tax_state",     type = "NUMERIC",   mode = "NULLABLE" },
    { name = "deferred_tax_foreign",   type = "NUMERIC",   mode = "NULLABLE" },
    { name = "deferred_tax_total",     type = "NUMERIC",   mode = "NULLABLE" },
    { name = "total_tax_expense",      type = "NUMERIC",   mode = "NULLABLE" },
    { name = "effective_tax_rate",     type = "FLOAT64",   mode = "NULLABLE" },
    { name = "run_id",                 type = "STRING",    mode = "NULLABLE" },
    { name = "loaded_at",              type = "TIMESTAMP", mode = "NULLABLE" }
  ])
}

resource "google_bigquery_table" "etr_reconciliation_lines" {
  dataset_id          = google_bigquery_dataset.dise_reporting.dataset_id
  table_id            = "etr_reconciliation_lines"
  deletion_protection = false
  description         = "ETR reconciliation waterfall — statutory rate to effective rate. Produces Table A of ASU 2023-09 disclosure."
  labels              = merge(local.labels, { module = "tax_reconciliation", standard = "asu_2023_09" })

  time_partitioning {
    type  = "DAY"
    field = "loaded_date"
  }
  clustering = ["company_code", "fiscal_year"]

  schema = jsonencode([
    { name = "company_code",       type = "STRING",    mode = "REQUIRED" },
    { name = "fiscal_year",        type = "STRING",    mode = "REQUIRED" },
    { name = "fiscal_period",      type = "STRING",    mode = "REQUIRED" },
    { name = "line_sequence",      type = "INT64",     mode = "REQUIRED" },
    { name = "etr_line_category",  type = "STRING",    mode = "REQUIRED" },
    { name = "line_label",         type = "STRING",    mode = "NULLABLE" },
    { name = "is_prescribed",      type = "BOOL",      mode = "NULLABLE" },
    { name = "materiality_pct",    type = "FLOAT64",   mode = "NULLABLE" },
    { name = "amount",             type = "NUMERIC",   mode = "NULLABLE" },
    { name = "pretax_income",      type = "NUMERIC",   mode = "NULLABLE" },
    { name = "rate_pct",           type = "FLOAT64",   mode = "NULLABLE" },
    { name = "jurisdiction_detail",type = "STRING",    mode = "NULLABLE" },
    { name = "run_id",             type = "STRING",    mode = "NULLABLE" },
    { name = "loaded_at",          type = "TIMESTAMP", mode = "NULLABLE" },
    { name = "loaded_date",        type = "DATE",      mode = "NULLABLE" }
  ])
}

resource "google_bigquery_table" "taxes_paid_fact" {
  dataset_id          = google_bigquery_dataset.dise_reporting.dataset_id
  table_id            = "taxes_paid_fact"
  deletion_protection = false
  description         = "Cash income taxes paid by jurisdiction. Produces Table B of ASU 2023-09 disclosure."
  labels              = merge(local.labels, { module = "tax_reconciliation", standard = "asu_2023_09" })

  time_partitioning {
    type  = "DAY"
    field = "loaded_date"
  }
  clustering = ["company_code", "fiscal_year", "jurisdiction_type"]

  schema = jsonencode([
    { name = "company_code",          type = "STRING",    mode = "REQUIRED" },
    { name = "fiscal_year",           type = "STRING",    mode = "REQUIRED" },
    { name = "fiscal_period",         type = "STRING",    mode = "REQUIRED" },
    { name = "jurisdiction_type",     type = "STRING",    mode = "REQUIRED" },
    { name = "jurisdiction_name",     type = "STRING",    mode = "NULLABLE" },
    { name = "country_code",          type = "STRING",    mode = "NULLABLE" },
    { name = "taxes_paid_amount",     type = "NUMERIC",   mode = "NULLABLE" },
    { name = "taxes_paid_abs",        type = "NUMERIC",   mode = "NULLABLE" },
    { name = "currency",              type = "STRING",    mode = "NULLABLE" },
    { name = "gl_accounts_included",  type = "STRING",    mode = "NULLABLE" },
    { name = "posting_count",         type = "INT64",     mode = "NULLABLE" },
    { name = "run_id",                type = "STRING",    mode = "NULLABLE" },
    { name = "loaded_at",             type = "TIMESTAMP", mode = "NULLABLE" },
    { name = "loaded_date",           type = "DATE",      mode = "NULLABLE" }
  ])
}

resource "google_bigquery_table" "jurisdiction_statutory_rates" {
  dataset_id          = google_bigquery_dataset.dise_reporting.dataset_id
  table_id            = "jurisdiction_statutory_rates"
  deletion_protection = false
  description         = "Statutory income tax rates by jurisdiction and year. Anchor for ETR bridge starting line."
  labels              = merge(local.labels, { module = "tax_reconciliation" })

  schema = jsonencode([
    { name = "jurisdiction_type", type = "STRING",    mode = "REQUIRED" },
    { name = "jurisdiction_name", type = "STRING",    mode = "REQUIRED" },
    { name = "country_code",      type = "STRING",    mode = "NULLABLE" },
    { name = "effective_year",    type = "INT64",     mode = "REQUIRED" },
    { name = "statutory_rate",    type = "FLOAT64",   mode = "REQUIRED" },
    { name = "notes",             type = "STRING",    mode = "NULLABLE" },
    { name = "source",            type = "STRING",    mode = "NULLABLE" },
    { name = "updated_at",        type = "TIMESTAMP", mode = "NULLABLE" }
  ])
}

resource "google_bigquery_table" "tax_disclosure_output" {
  dataset_id          = google_bigquery_dataset.dise_reporting.dataset_id
  table_id            = "tax_disclosure_output"
  deletion_protection = false
  description         = "Final ASU 2023-09 disclosure output — Tables A, B, and C. Audit-ready, Controller-approved."
  labels              = merge(local.labels, { module = "tax_reconciliation", standard = "asu_2023_09" })

  time_partitioning {
    type  = "DAY"
    field = "loaded_date"
  }
  clustering = ["company_code", "fiscal_year", "disclosure_table"]

  schema = jsonencode([
    { name = "company_code",     type = "STRING",    mode = "REQUIRED" },
    { name = "fiscal_year",      type = "STRING",    mode = "REQUIRED" },
    { name = "disclosure_table", type = "STRING",    mode = "REQUIRED", description = "A = ETR reconciliation | B = taxes paid | C = pretax income split" },
    { name = "line_sequence",    type = "INT64",     mode = "REQUIRED" },
    { name = "line_label",       type = "STRING",    mode = "NULLABLE" },
    { name = "current_year_pct", type = "FLOAT64",   mode = "NULLABLE" },
    { name = "current_year_amt", type = "NUMERIC",   mode = "NULLABLE" },
    { name = "prior_year_pct",   type = "FLOAT64",   mode = "NULLABLE" },
    { name = "prior_year_amt",   type = "NUMERIC",   mode = "NULLABLE" },
    { name = "is_total_row",     type = "BOOL",      mode = "NULLABLE" },
    { name = "source_table",     type = "STRING",    mode = "NULLABLE" },
    { name = "run_id",           type = "STRING",    mode = "NULLABLE" },
    { name = "approved_by",      type = "STRING",    mode = "NULLABLE" },
    { name = "approved_at",      type = "TIMESTAMP", mode = "NULLABLE" },
    { name = "loaded_at",        type = "TIMESTAMP", mode = "NULLABLE" },
    { name = "loaded_date",      type = "DATE",      mode = "NULLABLE" }
  ])
}


resource "google_bigquery_table" "etr_narrative_drafts" {
  dataset_id          = google_bigquery_dataset.dise_reporting.dataset_id
  table_id            = "etr_narrative_drafts"
  deletion_protection = false
  description         = "ASU 2023-09 qualitative ETR narrative drafts generated by Claude (Anthropic API). 60-120 words per item. Controller-reviewed before inclusion in 10-K footnote."
  labels              = merge(local.labels, { module = "tax_reconciliation", standard = "asu_2023_09" })

  time_partitioning {
    type  = "DAY"
    field = "loaded_date"
  }

  schema = jsonencode([
    { name = "run_id",                  type = "STRING",    mode = "NULLABLE" },
    { name = "company_code",            type = "STRING",    mode = "NULLABLE" },
    { name = "fiscal_year",             type = "STRING",    mode = "NULLABLE" },
    { name = "etr_line_category",       type = "STRING",    mode = "NULLABLE" },
    { name = "display_label",           type = "STRING",    mode = "NULLABLE" },
    { name = "amount",                  type = "NUMERIC",   mode = "NULLABLE" },
    { name = "rate_pct",                type = "FLOAT64",   mode = "NULLABLE" },
    { name = "disclosure_heading",      type = "STRING",    mode = "NULLABLE", description = "Short heading max 8 words" },
    { name = "narrative",               type = "STRING",    mode = "NULLABLE", description = "60-120 word audit-ready qualitative footnote explanation per ASC 740-10-50-12C" },
    { name = "ai_confidence",           type = "FLOAT64",   mode = "NULLABLE" },
    { name = "requires_tax_sme_review", type = "BOOL",      mode = "NULLABLE" },
    { name = "review_notes",            type = "STRING",    mode = "NULLABLE" },
    { name = "model_used",              type = "STRING",    mode = "NULLABLE", description = "e.g. claude-sonnet-4-20250514" },
    { name = "drafted_at",              type = "TIMESTAMP", mode = "NULLABLE" },
    { name = "approved",                type = "BOOL",      mode = "NULLABLE" },
    { name = "approved_by",             type = "STRING",    mode = "NULLABLE" },
    { name = "approved_at",             type = "STRING",    mode = "NULLABLE" },
    { name = "loaded_date",             type = "DATE",      mode = "NULLABLE" }
  ])
}


# ============================================================
# SECTION 4 — MODULE 3: SEGMENT REPORTING TABLES (ASU 2023-07)
# 3 tables — segment mapping, expense fact, disclosure output
# ============================================================

resource "google_bigquery_table" "segment_mapping" {
  dataset_id          = google_bigquery_dataset.dise_reporting.dataset_id
  table_id            = "segment_mapping"
  deletion_protection = false
  description         = "Maps SAP profit center prefixes (bseg.prctr) to ASU 2023-07 CODM operating segments. Validated against vbrp for ASC 280 10% revenue test."
  labels              = merge(local.labels, { module = "segment_reporting", standard = "asu_2023_07" })

  schema = jsonencode([
    { name = "prctr_prefix",  type = "STRING",    mode = "REQUIRED", description = "LEFT(prctr, 8) — SAP profit center prefix" },
    { name = "segment_id",    type = "STRING",    mode = "REQUIRED", description = "SEG01-SEG06 | CORP | OTHER" },
    { name = "segment_name",  type = "STRING",    mode = "REQUIRED", description = "Human-readable CODM segment name" },
    { name = "segment_type",  type = "STRING",    mode = "REQUIRED", description = "operating | corporate | other" },
    { name = "is_reportable", type = "BOOL",      mode = "REQUIRED", description = "TRUE = separately reportable per ASC 280 10% test" },
    { name = "created_at",    type = "TIMESTAMP", mode = "NULLABLE" }
  ])
}

resource "google_bigquery_table" "segment_expense_fact" {
  dataset_id          = google_bigquery_dataset.dise_reporting.dataset_id
  table_id            = "segment_expense_fact"
  deletion_protection = false
  description         = "Segment expense postings — joins bseg.prctr to CODM segments for ASU 2023-07. Enriched with DISE category from gl_dise_mapping."
  labels              = merge(local.labels, { module = "segment_reporting", standard = "asu_2023_07" })

  time_partitioning {
    type  = "MONTH"
    field = "loaded_at"
  }
  clustering = ["segment_id", "fiscal_year"]

  schema = jsonencode([
    { name = "company_code",   type = "STRING",    mode = "NULLABLE" },
    { name = "fiscal_year",    type = "STRING",    mode = "NULLABLE" },
    { name = "fiscal_period",  type = "STRING",    mode = "NULLABLE" },
    { name = "segment_id",     type = "STRING",    mode = "NULLABLE" },
    { name = "segment_name",   type = "STRING",    mode = "NULLABLE" },
    { name = "gl_account",     type = "STRING",    mode = "NULLABLE" },
    { name = "dise_category",  type = "STRING",    mode = "NULLABLE" },
    { name = "posting_count",  type = "INT64",     mode = "NULLABLE" },
    { name = "total_amount",   type = "NUMERIC",   mode = "NULLABLE" },
    { name = "currency",       type = "STRING",    mode = "NULLABLE" },
    { name = "run_id",         type = "STRING",    mode = "NULLABLE" },
    { name = "loaded_at",      type = "TIMESTAMP", mode = "NULLABLE" }
  ])
}

resource "google_bigquery_table" "segment_disclosure_output" {
  dataset_id          = google_bigquery_dataset.dise_reporting.dataset_id
  table_id            = "segment_disclosure_output"
  deletion_protection = false
  description         = "ASU 2023-07 segment disclosure output. ASC 280 10% revenue test applied. 4 reportable segments, Beverages aggregated into all other."
  labels              = merge(local.labels, { module = "segment_reporting", standard = "asu_2023_07" })

  time_partitioning {
    type  = "DAY"
    field = "loaded_date"
  }
  clustering = ["segment_id", "fiscal_year"]

  schema = jsonencode([
    { name = "company_code",   type = "STRING",    mode = "NULLABLE" },
    { name = "fiscal_year",    type = "STRING",    mode = "NULLABLE" },
    { name = "segment_id",     type = "STRING",    mode = "NULLABLE" },
    { name = "segment_name",   type = "STRING",    mode = "NULLABLE" },
    { name = "segment_type",   type = "STRING",    mode = "NULLABLE" },
    { name = "line_sequence",  type = "INT64",     mode = "NULLABLE" },
    { name = "line_label",     type = "STRING",    mode = "NULLABLE" },
    { name = "amount",         type = "NUMERIC",   mode = "NULLABLE" },
    { name = "currency",       type = "STRING",    mode = "NULLABLE" },
    { name = "is_total_row",   type = "BOOL",      mode = "NULLABLE" },
    { name = "pct_of_total",   type = "FLOAT64",   mode = "NULLABLE" },
    { name = "is_reportable",  type = "BOOL",      mode = "NULLABLE", description = "ASC 280 10% revenue threshold test result" },
    { name = "asc_280_basis",  type = "STRING",    mode = "NULLABLE", description = "Basis for reportability determination" },
    { name = "run_id",         type = "STRING",    mode = "NULLABLE" },
    { name = "loaded_at",      type = "TIMESTAMP", mode = "NULLABLE" },
    { name = "loaded_date",    type = "DATE",      mode = "NULLABLE" }
  ])
}


# ============================================================
# SECTION 5 — BIGQUERY VIEWS
# Three cross-module views for the GL Intelligence Platform
# ============================================================

resource "google_bigquery_table" "vw_dise_pivot" {
  dataset_id  = google_bigquery_dataset.dise_reporting.dataset_id
  table_id    = "vw_dise_pivot"
  description = "Real-time DISE expense disaggregation by category and caption."
  labels      = merge(local.labels, { module = "dise" })

  view {
    query = <<-SQL
      SELECT
        f.company_code, f.fiscal_year, f.fiscal_period,
        f.dise_category, f.expense_caption, f.segment_id,
        SUM(f.amount_local) AS total_amount,
        SUM(f.posting_count) AS posting_count,
        MAX(f.currency) AS currency,
        MAX(f.loaded_at) AS last_loaded
      FROM `${var.project_id}.${var.dataset_id}.fact_expense_disagg` f
      GROUP BY f.company_code, f.fiscal_year, f.fiscal_period,
               f.dise_category, f.expense_caption, f.segment_id
    SQL
    use_legacy_sql = false
  }
}

resource "google_bigquery_table" "vw_etr_summary" {
  dataset_id  = google_bigquery_dataset.dise_reporting.dataset_id
  table_id    = "vw_etr_summary"
  description = "ASU 2023-09 ETR reconciliation summary — latest run per company and fiscal year."
  labels      = merge(local.labels, { module = "tax_reconciliation" })

  view {
    query = <<-SQL
      SELECT
        company_code, fiscal_year, disclosure_table,
        line_sequence, line_label,
        current_year_amt, current_year_pct,
        is_total_row, run_id, loaded_at
      FROM `${var.project_id}.${var.dataset_id}.tax_disclosure_output`
      WHERE loaded_date = (
        SELECT MAX(loaded_date)
        FROM `${var.project_id}.${var.dataset_id}.tax_disclosure_output`
      )
      ORDER BY disclosure_table, line_sequence
    SQL
    use_legacy_sql = false
  }
}

resource "google_bigquery_table" "vw_segment_summary" {
  dataset_id  = google_bigquery_dataset.dise_reporting.dataset_id
  table_id    = "vw_segment_summary"
  description = "ASU 2023-07 segment disclosure summary — latest run, ASC 280 10% test applied."
  labels      = merge(local.labels, { module = "segment_reporting" })

  view {
    query = <<-SQL
      SELECT
        company_code, fiscal_year, segment_id, segment_name,
        line_sequence, amount, pct_of_total,
        is_reportable, asc_280_basis, run_id
      FROM `${var.project_id}.${var.dataset_id}.segment_disclosure_output`
      WHERE loaded_date = (
        SELECT MAX(loaded_date)
        FROM `${var.project_id}.${var.dataset_id}.segment_disclosure_output`
      )
      ORDER BY line_sequence
    SQL
    use_legacy_sql = false
  }
}


# ============================================================
# SECTION 6 — IAM AND SERVICE ACCOUNT
# ============================================================

resource "google_service_account" "fasb_agent" {
  account_id   = "fasb-agent-${var.client_id}"
  display_name = "FASB GL Intelligence Agent — ${var.client_name}"
  description  = "Service account for GL mapping agent, tax classifier, and ETR bridge. Least-privilege access."
}

resource "google_bigquery_dataset_iam_member" "fasb_agent_editor" {
  dataset_id = google_bigquery_dataset.dise_reporting.dataset_id
  role       = "roles/bigquery.dataEditor"
  member     = "serviceAccount:${local.sa_email}"
}

resource "google_project_iam_member" "fasb_agent_job_user" {
  project = var.project_id
  role    = "roles/bigquery.jobUser"
  member  = "serviceAccount:${local.sa_email}"
}

resource "google_bigquery_dataset_iam_member" "fasb_agent_cdc_reader" {
  dataset_id = var.cdc_dataset
  role       = "roles/bigquery.dataViewer"
  member     = "serviceAccount:${local.sa_email}"
}

resource "google_project_iam_member" "fasb_agent_vertex_user" {
  project = var.project_id
  role    = "roles/aiplatform.user"
  member  = "serviceAccount:${local.sa_email}"
}

resource "google_project_iam_member" "fasb_agent_secret_accessor" {
  project = var.project_id
  role    = "roles/secretmanager.secretAccessor"
  member  = "serviceAccount:${local.sa_email}"
}

resource "google_project_iam_member" "fasb_agent_run_invoker" {
  project = var.project_id
  role    = "roles/run.invoker"
  member  = "serviceAccount:${local.sa_email}"
}

resource "google_project_iam_member" "bq_transfer_agent" {
  project = var.project_id
  role    = "roles/bigquery.dataEditor"
  member  = "serviceAccount:service-${data.google_project.project.number}@gcp-sa-bigquerydatatransfer.iam.gserviceaccount.com"
}


# ============================================================
# SECTION 7 — SECRET MANAGER
# Anthropic API key — used by tax narrative drafter and
# segment classifier (both Claude-based, replaces Vertex AI)
# ============================================================

resource "google_secret_manager_secret" "anthropic_api_key" {
  secret_id = "fasb-anthropic-api-key-${var.client_id}"
  labels    = local.labels
  replication { auto {} }
}

resource "google_secret_manager_secret_version" "anthropic_api_key" {
  secret      = google_secret_manager_secret.anthropic_api_key.id
  secret_data = var.anthropic_api_key
}


# ============================================================
# SECTION 8 — CLOUD RUN: DISE MAPPING AGENT
# ============================================================

resource "google_cloud_run_v2_job" "dise_mapping_agent" {
  name     = "dise-mapping-agent-${var.client_id}"
  location = var.region

  template {
    template {
      service_account = local.sa_email
      containers {
        image = var.dise_agent_image
        env { name = "GCP_PROJECT";           value = var.project_id }
        env { name = "BQ_DATASET";            value = var.dataset_id }
        env { name = "BQ_CDC_DATASET";        value = var.cdc_dataset }
        env { name = "VERTEX_LOCATION";       value = var.region }
        env { name = "COMPANY_CODE";          value = var.company_code }
        env { name = "CONFIDENCE_THRESHOLD";  value = var.confidence_threshold }
        resources { limits = { cpu = "2", memory = "2Gi" } }
      }
      max_retries = 2
      timeout     = "3600s"
    }
  }

  depends_on = [
    google_bigquery_table.gl_dise_mapping,
    google_bigquery_table.pending_mappings,
  ]
}


# ============================================================
# SECTION 9 — CLOUD RUN: TAX NARRATIVE DRAFTER
# Runs tax_narrative_drafter.py via Anthropic API (Claude)
# Generates 60-120 word audit-ready ETR narratives per
# ASC 740-10-50-12C for items exceeding 5% materiality threshold
# Replaces Gemini/Vertex AI — no truncation issues
# ============================================================

resource "google_cloud_run_v2_job" "tax_narrative_drafter" {
  name     = "tax-narrative-drafter-${var.client_id}"
  location = var.region

  template {
    template {
      service_account = local.sa_email
      containers {
        image = var.tax_classifier_image
        env { name = "GCP_PROJECT";  value = var.project_id }
        env { name = "BQ_DATASET";   value = var.dataset_id }
        env { name = "COMPANY_CODE"; value = var.company_code }
        env { name = "MODEL";        value = var.claude_model }
        env {
          name = "ANTHROPIC_API_KEY"
          value_source {
            secret_key_ref {
              secret  = google_secret_manager_secret.anthropic_api_key.secret_id
              version = "latest"
            }
          }
        }
        resources { limits = { cpu = "1", memory = "512Mi" } }
      }
      max_retries = 2
      timeout     = "3600s"
    }
  }

  depends_on = [
    google_bigquery_table.etr_narrative_drafts,
    google_bigquery_table.etr_reconciliation_lines,
    google_secret_manager_secret.anthropic_api_key,
  ]
}


# ============================================================
# SECTION 9B — CLOUD RUN: SEGMENT CLASSIFIER
# Runs segment_classifier.py via Anthropic API (Claude)
# Classifies unclassified GL accounts in segment_expense_fact
# into DISE expense categories for ASU 2023-07 disclosure
# ============================================================

resource "google_cloud_run_v2_job" "segment_classifier" {
  name     = "segment-classifier-${var.client_id}"
  location = var.region

  template {
    template {
      service_account = local.sa_email
      containers {
        image = var.segment_classifier_image
        env { name = "GCP_PROJECT";  value = var.project_id }
        env { name = "BQ_DATASET";   value = var.dataset_id }
        env { name = "COMPANY_CODE"; value = var.company_code }
        env { name = "MODEL";        value = var.claude_model }
        env {
          name = "ANTHROPIC_API_KEY"
          value_source {
            secret_key_ref {
              secret  = google_secret_manager_secret.anthropic_api_key.secret_id
              version = "latest"
            }
          }
        }
        resources { limits = { cpu = "1", memory = "512Mi" } }
      }
      max_retries = 2
      timeout     = "3600s"
    }
  }

  depends_on = [
    google_bigquery_table.segment_expense_fact,
    google_bigquery_table.segment_mapping,
    google_secret_manager_secret.anthropic_api_key,
  ]
}


# ============================================================
# SECTION 10 — BIGQUERY SCHEDULED QUERIES
# DISE pivot: runs day 2 of month
# Tax ETR bridge: runs day 5 (after 2-day classifier review window)
# Segment pivot: runs day 2 alongside DISE
# ============================================================

resource "google_bigquery_data_transfer_config" "etr_bridge" {
  display_name           = "Tax ETR Bridge — ASU 2023-09 — ${var.client_id}"
  location               = var.bq_location
  data_source_id         = "scheduled_query"
  schedule               = var.tax_schedule_cron
  destination_dataset_id = google_bigquery_dataset.dise_reporting.dataset_id
  service_account_name   = local.sa_email

  params = {
    query = <<-SQL
      CREATE OR REPLACE TEMP TABLE raw_tax AS
      SELECT
        b.BUKRS AS company_code, b.GJAHR AS fiscal_year,
        b.MONAT AS fiscal_period, b.BUDAT AS posting_date,
        s.HKONT AS gl_account,
        s.DMBTR * CASE WHEN s.SHKZG = 'S' THEN 1 ELSE -1 END AS amount_local,
        b.WAERS AS currency, m.tax_category, m.jurisdiction_type,
        m.etr_line_category, m.pretax_income_type, m.taxes_paid_type
      FROM `${var.project_id}.${var.cdc_dataset}.bkpf` b
      JOIN `${var.project_id}.${var.cdc_dataset}.bseg` s
        ON b.MANDT=s.MANDT AND b.BUKRS=s.BUKRS AND b.BELNR=s.BELNR AND b.GJAHR=s.GJAHR
      JOIN `${var.project_id}.${var.dataset_id}.tax_gl_mapping` m
        ON s.HKONT=m.gl_account AND m.status='mapped'
      WHERE b.GJAHR=FORMAT_DATE('%Y',DATE_SUB(CURRENT_DATE(),INTERVAL 1 MONTH))
        AND (b.BSTAT IS NULL OR b.BSTAT IN ('0','A'))
        AND m.tax_category != 'not_applicable';

      CREATE OR REPLACE TEMP TABLE provision_summary AS
      SELECT company_code, fiscal_year, fiscal_period,
        MAX(posting_date) AS posting_date, MAX(currency) AS currency,
        SUM(IF(tax_category='current_tax' AND jurisdiction_type='federal',amount_local,0)) AS current_tax_federal,
        SUM(IF(tax_category='current_tax' AND jurisdiction_type='state',amount_local,0))   AS current_tax_state,
        SUM(IF(tax_category='current_tax' AND jurisdiction_type='foreign',amount_local,0)) AS current_tax_foreign,
        SUM(IF(tax_category='current_tax',amount_local,0))  AS current_tax_total,
        SUM(IF(tax_category='deferred_tax' AND jurisdiction_type='federal',amount_local,0)) AS deferred_tax_federal,
        SUM(IF(tax_category='deferred_tax' AND jurisdiction_type='state',amount_local,0))   AS deferred_tax_state,
        SUM(IF(tax_category='deferred_tax' AND jurisdiction_type='foreign',amount_local,0)) AS deferred_tax_foreign,
        SUM(IF(tax_category='deferred_tax',amount_local,0)) AS deferred_tax_total,
        SUM(IF(tax_category IN ('current_tax','deferred_tax'),amount_local,0)) AS total_tax_expense
      FROM raw_tax GROUP BY company_code, fiscal_year, fiscal_period;

      INSERT INTO `${var.project_id}.${var.dataset_id}.tax_provision_universe`
      (company_code,fiscal_year,fiscal_period,posting_date,currency,jurisdiction_type,
       current_tax_federal,current_tax_state,current_tax_foreign,current_tax_total,
       deferred_tax_federal,deferred_tax_state,deferred_tax_foreign,deferred_tax_total,
       total_tax_expense,run_id,loaded_at)
      SELECT company_code,fiscal_year,fiscal_period,posting_date,currency,'consolidated',
        current_tax_federal,current_tax_state,current_tax_foreign,current_tax_total,
        deferred_tax_federal,deferred_tax_state,deferred_tax_foreign,deferred_tax_total,
        total_tax_expense,
        CONCAT(FORMAT_DATE('%Y-%m',CURRENT_DATE()),'-auto'),
        CURRENT_TIMESTAMP()
      FROM provision_summary;
    SQL
  }

  depends_on = [
    google_bigquery_table.tax_provision_universe,
    google_bigquery_table.tax_disclosure_output,
    google_bigquery_table.tax_gl_mapping,
  ]
}


# ============================================================
# SECTION 11 — CLOUD SCHEDULER TRIGGERS
# DISE agent:          day 1 of month at 2am
# Tax narrative:       day 2 of month at 7am
# Segment classifier:  day 3 of month at 7am
# ETR bridge:          day 5 (via scheduled query — Section 10)
# ============================================================

resource "google_cloud_scheduler_job" "dise_agent_trigger" {
  name             = "dise-agent-trigger-${var.client_id}"
  description      = "Triggers DISE GL mapping agent on day 1 of each month"
  schedule         = "0 2 1 * *"
  time_zone        = var.scheduler_timezone
  attempt_deadline = "3600s"

  http_target {
    http_method = "POST"
    uri         = "https://${var.region}-run.googleapis.com/apis/run.googleapis.com/v1/namespaces/${var.project_id}/jobs/dise-mapping-agent-${var.client_id}:run"
    oauth_token { service_account_email = local.sa_email }
  }

  depends_on = [google_cloud_run_v2_job.dise_mapping_agent]
}

resource "google_cloud_scheduler_job" "tax_narrative_trigger" {
  name             = "tax-narrative-trigger-${var.client_id}"
  description      = "Triggers tax narrative drafter (Claude) on day 2 — drafts ETR qualitative narratives for Controller review"
  schedule         = "0 7 2 * *"
  time_zone        = var.scheduler_timezone
  attempt_deadline = "3600s"

  http_target {
    http_method = "POST"
    uri         = "https://${var.region}-run.googleapis.com/apis/run.googleapis.com/v1/namespaces/${var.project_id}/jobs/tax-narrative-drafter-${var.client_id}:run"
    oauth_token { service_account_email = local.sa_email }
  }

  depends_on = [google_cloud_run_v2_job.tax_narrative_drafter]
}

resource "google_cloud_scheduler_job" "segment_classifier_trigger" {
  name             = "segment-classifier-trigger-${var.client_id}"
  description      = "Triggers segment expense classifier (Claude) on day 3 — classifies unclassified GL accounts in segment_expense_fact"
  schedule         = "0 7 3 * *"
  time_zone        = var.scheduler_timezone
  attempt_deadline = "3600s"

  http_target {
    http_method = "POST"
    uri         = "https://${var.region}-run.googleapis.com/apis/run.googleapis.com/v1/namespaces/${var.project_id}/jobs/segment-classifier-${var.client_id}:run"
    oauth_token { service_account_email = local.sa_email }
  }

  depends_on = [google_cloud_run_v2_job.segment_classifier]
}


# ============================================================
# SECTION 12 — OUTPUTS
# ============================================================

output "dataset_id" {
  description = "BigQuery dataset containing all FASB compliance tables"
  value       = google_bigquery_dataset.dise_reporting.dataset_id
}

output "service_account_email" {
  description = "Service account email for the FASB agent"
  value       = local.sa_email
}

output "dise_agent_job" {
  description = "Cloud Run job name for the DISE GL mapping agent"
  value       = google_cloud_run_v2_job.dise_mapping_agent.name
}

output "tax_narrative_drafter_job" {
  description = "Cloud Run job name for the tax narrative drafter (Claude / Anthropic API)"
  value       = google_cloud_run_v2_job.tax_narrative_drafter.name
}

output "segment_classifier_job" {
  description = "Cloud Run job name for the segment expense classifier (Claude / Anthropic API)"
  value       = google_cloud_run_v2_job.segment_classifier.name
}

output "etr_bridge_query" {
  description = "BigQuery scheduled query name for the ETR bridge"
  value       = google_bigquery_data_transfer_config.etr_bridge.display_name
}

output "anthropic_secret_id" {
  description = "Secret Manager secret ID for the Anthropic API key"
  value       = google_secret_manager_secret.anthropic_api_key.secret_id
  sensitive   = true
}

output "all_tables" {
  description = "All 18 BigQuery tables across three FASB mandate modules"
  value = {
    dise = [
      google_bigquery_table.gl_dise_mapping.table_id,
      google_bigquery_table.fact_expense_disagg.table_id,
      google_bigquery_table.pending_mappings.table_id,
      google_bigquery_table.mapping_decisions_log.table_id,
      google_bigquery_table.anomaly_alerts.table_id,
      google_bigquery_table.close_tasks.table_id,
      google_bigquery_table.close_task_history.table_id,
    ]
    tax = [
      google_bigquery_table.tax_gl_mapping.table_id,
      google_bigquery_table.tax_pending_mappings.table_id,
      google_bigquery_table.tax_provision_universe.table_id,
      google_bigquery_table.etr_reconciliation_lines.table_id,
      google_bigquery_table.taxes_paid_fact.table_id,
      google_bigquery_table.jurisdiction_statutory_rates.table_id,
      google_bigquery_table.tax_disclosure_output.table_id,
      google_bigquery_table.etr_narrative_drafts.table_id,
    ]
    segments = [
      google_bigquery_table.segment_mapping.table_id,
      google_bigquery_table.segment_expense_fact.table_id,
      google_bigquery_table.segment_disclosure_output.table_id,
    ]
  }
}
