# GL Intelligence Platform — FASB Terraform Deployment Guide
# BE Technology · diplomatic75
# Covers: DISE (ASU 2024-03) · Tax Recon (ASU 2023-09) · Segments (ASU 2023-07)

## What this provisions

One terraform apply command creates the complete FASB compliance infrastructure
for a new client in under 5 minutes:

  Module 1 — DISE (ASU 2024-03)
    7 BigQuery tables: gl_dise_mapping, fact_expense_disagg, pending_mappings,
    mapping_decisions_log, anomaly_alerts, close_tasks, close_task_history

  Module 2 — Tax Reconciliation (ASU 2023-09)
    8 BigQuery tables: tax_gl_mapping, tax_pending_mappings, tax_provision_universe,
    etr_reconciliation_lines, taxes_paid_fact, jurisdiction_statutory_rates,
    tax_disclosure_output, etr_narrative_drafts

  Module 3 — Segment Reporting (ASU 2023-07)
    3 BigQuery tables: segment_mapping, segment_expense_fact, segment_disclosure_output

  Shared infrastructure
    3 BigQuery views (vw_dise_pivot, vw_etr_summary, vw_segment_summary)
    1 Service account with least-privilege IAM
    1 Secret Manager secret (Anthropic API key)
    3 Cloud Run jobs (DISE agent + Tax narrative drafter + Segment classifier)
    3 Cloud Scheduler triggers
    1 BigQuery scheduled query (ETR bridge)


## Prerequisites

  1. GCP project with billing enabled
  2. APIs enabled:
     gcloud services enable bigquery.googleapis.com
     gcloud services enable run.googleapis.com
     gcloud services enable cloudscheduler.googleapis.com
     gcloud services enable secretmanager.googleapis.com
     gcloud services enable aiplatform.googleapis.com
     gcloud services enable bigquerydatatransfer.googleapis.com

  3. Cortex Framework deployed with CORTEX_SAP_CDC dataset populated
  4. Terraform >= 1.5 installed
  5. Docker images built and pushed (see below)


## Build and push Docker images

  # DISE mapping agent
  docker build -f Dockerfile.agent -t gcr.io/{project}/dise-agent:latest .
  docker push gcr.io/{project}/dise-agent:latest

  # Tax classifier
  docker build -f Dockerfile.tax -t gcr.io/{project}/tax-classifier:latest .
  docker push gcr.io/{project}/tax-classifier:latest


## Deploy a new client

  # 1. Create workspace
  terraform workspace new {client_id}

  # 2. Create client config
  cp fasb_terraform.tfvars.example clients/{client_id}.tfvars
  # Edit clients/{client_id}.tfvars with client values

  # 3. Initialize and plan
  terraform init
  terraform plan -var-file=clients/{client_id}.tfvars

  # 4. Apply
  terraform apply -var-file=clients/{client_id}.tfvars

  # 5. Verify
  terraform output


## Import existing resources (diplomatic75)

  If tables were manually created before Terraform, import them first:

  terraform import google_bigquery_dataset.dise_reporting \
    projects/diplomatic75/datasets/dise_reporting

  terraform import google_bigquery_table.gl_dise_mapping \
    diplomatic75/dise_reporting/gl_dise_mapping

  terraform import google_bigquery_table.tax_gl_mapping \
    diplomatic75/dise_reporting/tax_gl_mapping

  # Repeat for each table that already exists


## Multi-client management

  terraform workspace list           # list all clients
  terraform workspace select acme    # switch to acme client
  terraform apply -var-file=clients/acme.tfvars

  Each workspace is completely isolated — separate state file,
  separate resource names (suffixed with client_id), separate
  service accounts.


## Post-deployment steps

  After terraform apply:

  1. Seed statutory rates (tax module):
     INSERT INTO dise_reporting.jurisdiction_statutory_rates ...
     (US Federal 21%, state rates, foreign rates per client)

  2. Seed segment mapping (segment module):
     INSERT INTO dise_reporting.segment_mapping ...
     (Map client profit center prefixes to CODM segments)
     Run ASC 280 10% revenue test via vbrp billing data.

  3. Run DISE classifier manually to bootstrap GL mapping:
     gcloud run jobs execute dise-mapping-agent-{client_id} --region=us-central1

  4. Run tax classifier manually to bootstrap tax GL mapping:
     gcloud run jobs execute tax-classifier-{client_id} --region=us-central1

  5. Review pending mappings with Controller, approve in BigQuery

  6. Run ETR bridge SQL manually for first disclosure output

  7. Validate output in GL Intelligence Platform dashboard


## Schedule summary

  Day 1 of month — DISE mapping agent (Cloud Scheduler · 2am)
  Day 3 of month — Tax classifier (Cloud Scheduler · 6am)
  Day 5 of month — ETR bridge SQL (BigQuery scheduled query · 6am)

  2-day review window between classifier run (day 3) and
  ETR bridge (day 5) for Controller to review pending mappings.


## Cost estimate per client per month

  BigQuery storage:           $5-25
  Cloud Run (DISE agent):     $2-5
  Cloud Run (tax classifier): $2-5
  Cloud Scheduler:            < $1
  Secret Manager:             < $1
  Vertex AI (Gemini calls):   $3-8

  Total:                      ~$15-45/month

  At $75K-$150K ACV per client, infrastructure is
  less than 0.05% of revenue.


## Table count summary

  DISE module:     7 tables
  Tax module:      7 tables
  Segment module:  3 tables
  Shared views:    3 views
  Total:          17 tables + 3 views = 20 BigQuery resources
