# ============================================================
# BE Technology — GL Intelligence Platform
# variables.tf — all three FASB mandate modules
# ============================================================

# ── Required per client ───────────────────────────────────────

variable "client_id" {
  description = "Short unique identifier for this client. Used in resource names. Lowercase alphanumeric and hyphens only. e.g. acme-mfg"
  type        = string
  validation {
    condition     = can(regex("^[a-z0-9-]+$", var.client_id))
    error_message = "client_id must be lowercase alphanumeric and hyphens only."
  }
}

variable "client_name" {
  description = "Full client name for display in resource descriptions. e.g. Acme Manufacturing Inc."
  type        = string
}

variable "project_id" {
  description = "GCP project ID for this client deployment. e.g. diplomatic75"
  type        = string
}

variable "admin_email" {
  description = "GCP admin email — gets OWNER access to the BigQuery dataset."
  type        = string
}

variable "controller_email" {
  description = "Controller or CFO email — gets READER access to the dataset and receives approval notifications."
  type        = string
}

variable "company_code" {
  description = "SAP company code for this client. e.g. C006"
  type        = string
}

# ── Infrastructure ────────────────────────────────────────────

variable "region" {
  description = "GCP region for Cloud Run and Vertex AI. Default: us-central1"
  type        = string
  default     = "us-central1"
}

variable "bq_location" {
  description = "BigQuery dataset location. Default: US"
  type        = string
  default     = "US"
}

variable "environment" {
  description = "Deployment environment label. e.g. production | staging | dev"
  type        = string
  default     = "production"
  validation {
    condition     = contains(["production", "staging", "dev"], var.environment)
    error_message = "environment must be production, staging, or dev."
  }
}

variable "dataset_id" {
  description = "BigQuery dataset name for the FASB compliance layer."
  type        = string
  default     = "dise_reporting"
}

variable "cdc_dataset" {
  description = "BigQuery dataset containing SAP Cortex CDC tables. e.g. CORTEX_SAP_CDC"
  type        = string
  default     = "CORTEX_SAP_CDC"
}

variable "scheduler_timezone" {
  description = "Timezone for Cloud Scheduler jobs."
  type        = string
  default     = "America/New_York"
}

# ── Module 1: DISE (ASU 2024-03) ─────────────────────────────

variable "dise_agent_image" {
  description = "Container image URI for the DISE GL mapping agent Cloud Run job."
  type        = string
  default     = "gcr.io/diplomatic75/dise-agent:latest"
}

variable "confidence_threshold" {
  description = "Gemini confidence threshold for DISE auto-approval. Accounts below this go to human review."
  type        = string
  default     = "0.80"
  validation {
    condition     = tonumber(var.confidence_threshold) >= 0.5 && tonumber(var.confidence_threshold) <= 1.0
    error_message = "confidence_threshold must be between 0.50 and 1.00."
  }
}

# ── Module 2: Tax Reconciliation (ASU 2023-09) ───────────────

variable "tax_classifier_image" {
  description = "Container image URI for the tax GL classifier Cloud Run job."
  type        = string
  default     = "gcr.io/diplomatic75/tax-classifier:latest"
}

variable "tax_confidence_threshold" {
  description = "Gemini confidence threshold for tax GL auto-approval."
  type        = string
  default     = "0.80"
  validation {
    condition     = tonumber(var.tax_confidence_threshold) >= 0.5 && tonumber(var.tax_confidence_threshold) <= 1.0
    error_message = "tax_confidence_threshold must be between 0.50 and 1.00."
  }
}

variable "tax_schedule_cron" {
  description = "Cron schedule for the ETR bridge BigQuery scheduled query. Default: 6am on the 5th of each month."
  type        = string
  default     = "0 6 5 * *"
}

variable "tax_gl_account_range_start" {
  description = "Start of the SAP GL account range containing income tax accounts. Varies by client chart of accounts. diplomatic75: 0000160000"
  type        = string
  default     = "0000160000"
}

variable "tax_gl_account_range_end" {
  description = "End of the SAP GL account range containing income tax accounts."
  type        = string
  default     = "0000199999"
}

variable "tax_federal_statutory_rate" {
  description = "Federal statutory income tax rate as decimal. Default 0.21 for post-TCJA US rate."
  type        = number
  default     = 0.21
  validation {
    condition     = var.tax_federal_statutory_rate > 0 && var.tax_federal_statutory_rate < 1
    error_message = "Statutory rate must be between 0 and 1 (e.g. 0.21 for 21%)."
  }
}

# ── Module 3: Segment Reporting (ASU 2023-07) ────────────────

variable "segment_revenue_threshold" {
  description = "ASC 280 10% revenue threshold for separate segment reportability. Default: 0.10"
  type        = number
  default     = 0.10
  validation {
    condition     = var.segment_revenue_threshold > 0 && var.segment_revenue_threshold <= 0.25
    error_message = "segment_revenue_threshold must be between 0.01 and 0.25."
  }
}

variable "segment_adequacy_threshold" {
  description = "ASC 280 75% revenue adequacy test threshold. Default: 0.75"
  type        = number
  default     = 0.75
  validation {
    condition     = var.segment_adequacy_threshold >= 0.75 && var.segment_adequacy_threshold <= 1.0
    error_message = "segment_adequacy_threshold must be between 0.75 and 1.00."
  }
}

variable "segment_classifier_image" {
  description = "Container image URI for the segment expense classifier Cloud Run job (Claude-based)."
  type        = string
  default     = "gcr.io/diplomatic75/segment-classifier:latest"
}

# ── Anthropic / Claude settings ───────────────────────────────

variable "anthropic_api_key" {
  description = "Anthropic API key for Claude. Stored in Secret Manager. Set via TF_VAR_anthropic_api_key — never commit to git."
  type        = string
  sensitive   = true
}

variable "claude_model" {
  description = "Anthropic Claude model version used by the tax narrative drafter and segment classifier."
  type        = string
  default     = "claude-sonnet-4-20250514"
}
